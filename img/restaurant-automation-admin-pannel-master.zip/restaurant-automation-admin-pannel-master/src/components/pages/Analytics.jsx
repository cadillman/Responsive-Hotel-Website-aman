import React from 'react';
import Drawer from "../navbar/Drawer.jsx";

function About(){
  return(
    <div>
    <Drawer content="Analytics">
    </Drawer>
    </div>
  )
}
export default About;
