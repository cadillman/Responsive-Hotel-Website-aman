import React from 'react';
import Drawer from "../navbar/Drawer.jsx";

function About(){
  return(
    <div>
    <Drawer content="Terms and Condition">
    </Drawer>
    </div>
  )
}
export default About;
