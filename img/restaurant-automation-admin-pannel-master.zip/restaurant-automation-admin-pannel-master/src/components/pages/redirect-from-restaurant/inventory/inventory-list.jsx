import React from 'react';
import Drawer from "../../../navbar/Drawer.jsx";

//custom components
import  * as Template from "../../../restaurants/inventory-list/inventory-list-template.jsx";

{/*passing content prop in drawer to update content exporting all functions to paths
  in order to render required content according to path mapping*/}
function inventoryList(){
  return(
    <div>
    <Drawer content=<Template.inventoryListTemplate/>/>
    </div>
  )
}
export default inventoryList;
